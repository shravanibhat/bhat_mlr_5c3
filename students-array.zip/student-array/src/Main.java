public class Main {

	public static void main(String[] args) {
		
		//You may test that your code works find here
		//Please check that your code works and has no 
		//compilation problems before to submit
		Scanner s=new Scanner(System.in);
		Student ob=new Student();
		ob.setId();
		ob.setFullName();
		ob.setBirthDate();
		ob.setAvgMark();
		
	}

}
